SeaTrade V 1.01

Fehlerkorrekturen:
Natives Protokoll Company - SeaTrade:
- Companyname wird übernommen
- getinfo-Kommando zum Abfragen von harbour/cargo
SeaViewer: Refresh Company-Anzahl beim Exit einer Company

