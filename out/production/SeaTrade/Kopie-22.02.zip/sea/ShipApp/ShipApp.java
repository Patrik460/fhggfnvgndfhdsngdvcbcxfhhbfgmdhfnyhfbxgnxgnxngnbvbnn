package sea.ShipApp;

import sea.Basis.Direction;
import sea.Basis.Position;
import sea.CompanyApp.Cargo;
import sea.CompanyApp.RequestListener;

public class ShipApp {

	private String name;
	private Cargo cargo;
	private Position position;
	private Direction direction;
	private boolean loaded;
	private static String host = "localhost"; // 10.53.5.102
	private static int port = 8151;
	private SeaTradeReceiver seaTradeReceiver;
	private CompanyReceiver caReceiver;

	public ShipApp() {
		setSeaTradeReceiver(new SeaTradeReceiver());
		RequestListener rl = new RequestListener(12345);
		rl.start();
		setCompanyReceiver(new CompanyReceiver());
	}

	public static void main(String[] args) {
		new ShipApp();
	}

	private void setCompanyReceiver(CompanyReceiver caReceiver) {
		this.caReceiver = caReceiver;
	}

	public void loginCompany(String shipName, String companyName) {
		caReceiver.out.println("login:" + shipName + ":" + companyName);
	}

	public void logoutCompany() {
		caReceiver.out.println("logout:" + getName());
	}

	public void loginSeaTrade(String shipName, String companyName) {
		// überprüfen
		getSeaTradeReceiver().out.println("loginseatrade:" + shipName + ":" + companyName);
	}

	public void logoutSeaTrade() {
		// überprüfen
		getSeaTradeReceiver().out.println("logoutseatrade:" + getName());
	}

	public void receiveOrder() {
		// eigentlich unnötig
		getSeaTradeReceiver().out.println("receiveorder");
	}

	public void endOrder() {
		// überprüfen
		getSeaTradeReceiver().out.println("endorder");
	}

	public void loadCargo() {
		// überprüfen
		getSeaTradeReceiver().out.println("loadcargo");
		loaded = true;
	}

	public void unloadCargo() {
		// überprüfen
		getSeaTradeReceiver().out.println("unloadcargo");
	}

	public void loseCargo() {
		// überprüfen
		getSeaTradeReceiver().out.println("losecargo");
	}

	public void moveTo(String harbour) {
		getSeaTradeReceiver().out.println("moveto:" + harbour);
	}

	public void moveManualTo(Direction direction) {
		getSeaTradeReceiver().out.println("move:" + direction);
	}

	public void sendPos(Position position) {
		// überprüfen
		getSeaTradeReceiver().out.println("sendpos:" + position.getX() + ":" + position.getY());
	}

	public void sendDir(Direction direction) {
		// überprüfen
		getSeaTradeReceiver().out.println("senddir:" + direction.toString());
	}

	public void launch(String company, String harbour, String shipName) {
		getSeaTradeReceiver().out.println("launch:" + company + ":" + harbour + ":" + shipName);
	}

	public void sendProfit(Cargo cargo) {
		// überprüfen
		getSeaTradeReceiver().out.println("sendprofit:" + cargo.getValue());
	}

	public void getRadarRequest() {
		// überprüfen
		getSeaTradeReceiver().out.println("radarrequest");

		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void exit() {
		// überprüfen
		getSeaTradeReceiver().out.println("exit");
	}

	// Getter und Setter
	public Cargo getCargo() {
		return cargo;
	}

	public Direction getDirection() {
		return direction;
	}

	public static String getHost() {
		return host;
	}

	public String getName() {
		return name;
	}

	public static int getPort() {
		return port;
	}

	public Position getPosition() {
		return position;
	}

	public void setCargo(Cargo cargo) {
		this.cargo = cargo;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public void setHost(String host) {
		ShipApp.host = host;
	}

	public void setLoaded(boolean loaded) {
		this.loaded = loaded;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPort(int port) {
		ShipApp.port = port;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public boolean isLoaded() {
		return loaded;
	}

	public SeaTradeReceiver getSeaTradeReceiver() {
		return seaTradeReceiver;
	}

	public void setSeaTradeReceiver(SeaTradeReceiver seaTradeReceiver) {
		this.seaTradeReceiver = seaTradeReceiver;
	}
}
