package sea.ShipApp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JOptionPane;

import sea.Basis.Ground;
import sea.Basis.RadarField;
import sea.Erweiterungen.GUI.ShipAppGUI;

public class SeaTradeReceiver extends Thread {

	private Socket shipSocket = null;
	private BufferedReader in = null;
	public PrintWriter out = null;
	public static String radarCommand = "";
	public RadarField radarfield = new RadarField(Ground.HAFEN);
	private ShipAppGUI shipAppGUI;

	@Override
	public void run() {
		try {
			// Socket und Streams erzeugen
			shipSocket = new Socket(ShipApp.getHost(), ShipApp.getPort());
			in = new BufferedReader(new InputStreamReader(shipSocket.getInputStream()));
			out = new PrintWriter(shipSocket.getOutputStream(), true);

			System.out.println("Verbindung erfolgreich: " + ShipApp.getHost());

			String line;
			while ((line = in.readLine()) != null) {

				if (line.contains("radarscreen")) {
					radarCommand = line.split(":")[1];
				} else {
					System.out.println(line); // Radarnachrichten herausfiltern
				}

// Autopilot nur vom Hafen aus aktivierbar
				if (line.contains("reached")) {
					radarfield.setGround(Ground.HAFEN);
				} else {
					radarfield.setGround(Ground.WASSER);
				}

// Fehlermeldung
				if (line.contains("error")) {
					Object errorMessage;
					if (line.contains("money")) {
						errorMessage = "Error: Company hasn't enough moneyd.";
					} else {
						errorMessage = "Error: The Company is not registered.";
					}
					radarCommand = errorMessage.toString();
					JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);

				}
			}
		} catch (UnknownHostException e) {
			System.err.println("Unbekannter Hostname: " + ShipApp.getHost());
		} catch (IOException e) {
			System.err.println("Keine Verbindung zu '" + ShipApp.getHost() + "' moeglich");
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
				if (shipSocket != null && !shipSocket.isClosed()) {
					shipSocket.close();
				}
			} catch (IOException e) {
				System.err.println("Fehler beim Schließen der Ressourcen: " + e.getMessage());
			}
		}
		System.out.println("SeaTradeReceiver beendet");
	}

}
