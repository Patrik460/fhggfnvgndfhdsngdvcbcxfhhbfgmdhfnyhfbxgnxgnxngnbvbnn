package sea.ShipApp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class CompanyReceiver extends Thread {

	private Socket shipCompanySocket;
	private BufferedReader in;
	public PrintWriter out;

	@Override
	public void run() {
		try {
			// Socket und Streams erzeugen
			shipCompanySocket = new Socket(ShipApp.getHost(), ShipApp.getPort());
			in = new BufferedReader(new InputStreamReader(shipCompanySocket.getInputStream()));
			out = new PrintWriter(shipCompanySocket.getOutputStream(), true);

			System.out.println("Verbindung erfolgreich: " + ShipApp.getHost());

			String line;
			while ((line = in.readLine()) != null) {
				System.out.println(line); // Servernachricht anzeigen

				if (line.contains("loadcargo")) {
					// shipApp.
				}
			}
		} catch (UnknownHostException e) {
			System.err.println("Unbekannter Hostname: " + ShipApp.getHost());
		} catch (IOException e) {
			System.err.println("Keine Verbindung zu '" + ShipApp.getHost() + "' moeglich");
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
				if (shipCompanySocket != null && !shipCompanySocket.isClosed()) {
					shipCompanySocket.close();
				}
			} catch (IOException e) {
				System.err.println("Fehler beim Schließen der Ressourcen: " + e.getMessage());
			}
			System.out.println("CompanyReceiver beendet");
		}
	}
}
